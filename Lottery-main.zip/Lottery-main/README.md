# Lottery
Boundless Jackpot


## Repository setup

### Install

To install the needed packages run:

`yarn` 

### Build

To build the smart contracts run:

`npx hardhat compile` 


### Deploy

To deploy the contracts run:

`hardhat run scripts/deploy.js` 

